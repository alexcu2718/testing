


use arrow_extendr::to::IntoArrowRobj;
use calamine::{open_workbook_auto, Data, Reader, Range};
use extendr_api::prelude::*;
use arrow::record_batch::RecordBatch;
use arrow::datatypes::{Schema, Field, DataType};
use std::sync::Arc;
use arrow::array::{ArrayRef, StringArray};
use std::fs::File;
use std::io::{self};
use std::path::PathBuf;
use zip::read::ZipArchive;
/// Return string `"Hello world!"` to R.
/// @export
#[extendr]
fn rdexcelnu(file: String, sheet: String)->  Result<Robj> {
    let file_path = PathBuf::from(file);

    // Check if the file has a valid Excel extension
    match file_path.extension().and_then(|s| s.to_str()) {
        Some("xlsx") | Some("xlsm") | Some("xlsb") | Some("xls") => (),
        _ => return Err(Error::Other("Expecting an Excel file".into())),
    }

    let mut workbook = open_workbook_auto(&file_path)
        .map_err(|e| Error::Other(format!("Failed to open workbook: {}", e)))?;

    
    let range = workbook.worksheet_range(&sheet).unwrap();
  write_range_to_arrow(&range)
    //range.into_robj()
}

fn write_range_to_arrow(range: &Range<Data>) -> Result<Robj> {
    let mut columns: Vec<Vec<String>> = Vec::new();
    let mut column_names: Vec<String> = Vec::new();

    // Initialize columns based on the number of columns in the range
    for _ in 0..range.get_size().1 {
        columns.push(Vec::new());
    }

    let mut rows_iter = range.rows();

    // Skip the first row (we assume the first row is headers or irrelevant for type inference)
    let _first_row = rows_iter.next();

    // Infer column names based on the second row's data types
    if let Some(second_row) = rows_iter.next() {
        for (i, cell) in second_row.iter().enumerate() {
            let column_name = match cell {
                Data::Empty => format!("Empty_{}", i),
                Data::String(_) => format!("String_{}", i),
                Data::DateTimeIso(_) => format!("DateTimeIso_{}", i),
                Data::DurationIso(_) => format!("DurationIso_{}", i),
                Data::Float(_) => format!("Float_{}", i),
                Data::DateTime(_) => format!("DateTime_{}", i),
                Data::Int(_) => format!("Float_{}", i),
                Data::Error(_) => format!("Error_{}", i),
                Data::Bool(_) => format!("Bool_{}", i),
            };
            column_names.push(column_name);
        }
    }

    // Populate the columns with data (including the first row if you need it as data)
    for row in range.rows() {
        for (i, cell) in row.iter().enumerate() {
            let value = match cell {
                Data::Empty => String::from("NA"),
                Data::String(ref s) | Data::DateTimeIso(ref s) | Data::DurationIso(ref s) => s.clone(),
                Data::Float(ref f) => f.to_string(),
                Data::DateTime(ref d) => d.as_f64().to_string(),
                Data::Int(ref i) => i.to_string(),
                Data::Error(ref e) => format!("{:?}", e),
                Data::Bool(ref b) => b.to_string(),
            };
            columns[i].push(value);
        }
    }

    // Create Arrow Arrays from the columns
    let mut arrays: Vec<ArrayRef> = Vec::new();

    for column in columns {
        let array: ArrayRef = Arc::new(StringArray::from(column));
        arrays.push(array);
    }

    // Define Arrow Schema using the inferred column names
    let schema_fields: Vec<Field> = column_names.iter()
        .map(|name| Field::new(name, DataType::Utf8, false))
        .collect();

    let schema = Arc::new(Schema::new(schema_fields));
    let record_batch = RecordBatch::try_new(schema, arrays)
        .map_err(|e| Error::Other(format!("Failed to create RecordBatch: {}", e)))?;

    // Convert the RecordBatch to an R object using the IntoArrowRobj trait
    record_batch.into_arrow_robj()
}



//@export
#[extendr]
fn getsheets(file: String) -> Robj {
    let file_path = PathBuf::from(file);
    
    match open_workbook_auto(&file_path) {
        Ok(workbook) => {
            let sheet_names = workbook.sheet_names();
            sheet_names.into_robj()
        },
        Err(err) => {
            format!("Error opening workbook: {}", err).into_robj()
        }
    }
}

//@export
#[extendr]
fn unzip_password(filepath: String, output: String, password: String) -> String {
    // Convert the input strings to PathBuf
    let file_path = PathBuf::from(filepath);
    let output_dir = PathBuf::from(output);
    
    
    match File::open(&file_path) {
        Ok(file) => {
            let mut archive = match ZipArchive::new(file) {
                Ok(arch) => arch,
                Err(e) => return format!("Failed to open zip file: {}", e),
            };

           
            if let Err(e) = std::fs::create_dir_all(&output_dir) {
                return format!("Failed to create output directory: {}", e);
            }

            
            for i in 0..archive.len() {
                let mut file = match archive.by_index_decrypt(i, password.as_bytes()) {
                    Ok(f) => f,
                    Err(e) => return format!("Failed to decrypt file {}: {}", i, e),
                };

                let out_path = output_dir.join(file.name());
                if file.is_dir() {
                    // Create the directory if it's a folder
                    if let Err(e) = std::fs::create_dir_all(&out_path) {
                        return format!("Failed to create directory: {}", e);
                    }
                } else {
                    // Extract the file
                    if let Some(parent) = out_path.parent() {
                        if let Err(e) = std::fs::create_dir_all(parent) {
                            return format!("Failed to create parent directory: {}", e);
                        }
                    }
                    match File::create(&out_path) {
                        Ok(mut outfile) => {
                            if let Err(e) = io::copy(&mut file, &mut outfile) {
                                return format!("Failed to write file {}: {}", out_path.display(), e);
                            }
                        }
                        Err(e) => return format!("Failed to create file {}: {}", out_path.display(), e),
                    }
                }
            }

            format!("Successfully extracted to {}", output_dir.display())
        }
        Err(e) => format!("Failed to open zip file: {}", e),
    }
}



extendr_module! {
    mod scanfast;
    fn rdexcelnu;
    fn getsheets;
    fn unzip_password;
    
}
