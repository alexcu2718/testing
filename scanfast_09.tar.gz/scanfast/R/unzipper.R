
#' Unzip a password-protected zip file
#'
#' @param zipfile The path to the zip file
#' @param outputdir The directory where the unzipped files will be stored. Defaults to the zip file name without ".zip".
#' @param password The password for the zip file
#' @return The path to the output directory
#' @export
unzipper<-function(zipfile,outputdir=NULL,password){
  if(is.null(outputdir)){outputdir=stringr::str_remove_all(zipfile,'.zip')}
  if(!dir.exists(outputdir)){dir.create(outputdir)}
  unzip_password(zipfile,outputdir,password=password)
  return(outputdir)}
