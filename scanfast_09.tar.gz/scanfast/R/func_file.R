packages <- c("nanoarrow", "dplyr", "dtplyr", "rextendr", "data.table", "stringr","purrr","arrow","utils","devtools")

purrr::walk(packages, usethis::use_package)
library(data.table)
library(stringr)
library(dplyr)
library(dtplyr)
library(nanoarrow)
library(arrow)
library(purrr)

readexcel <- function(file, sheetname = NULL,skiprows=0) {
  if (!stringr::str_detect(file, '.xls')) {stop('Please provide an Excel file')}
  if (is.null(sheetname)) {sheetname <- getsheets(file)[1]}
  df <- rdexcelnu(file, sheet = sheetname) |> data.table::as.data.table()
  if(skiprows>0){skiprows=as.integer(skiprows);df=df[-(1:skiprows),]}
  colnames(df) <- unlist(head(df, 1))
  df <- df[-1, ]
  df=suppressWarnings({utils::type.convert(df)})
  return(df)
}

# Example usage
#eg <- readexcel(r"(C:\Users\alexc\OneDrive\Desktop\ONSPD_NOV_2022_UK_AB.xlsm)",sheet='eg3a',skiprows=3)


unzipper<-function(zipfile,outputdir=NULL,password){
  if(is.null(outputdir)){outputdir=stringr::str_remove_all(zipfile,'.zip')}
  if(!dir.exists(outputdir)){dir.create(outputdir)}
  unzip_password(zipfile,outputdir,password=password)
  return(outputdir)}


