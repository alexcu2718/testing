#' Read an Excel file and convert it to a data.table
#' 
#' @param file The path to the Excel file
#' @param sheetname The sheet name (optional)
#' @param skiprows Number of rows to skip at the start
#' @return A data.table with the contents of the Excel file
#' @export

readexcel <- function(file, sheetname = NULL,skiprows=0) {
  if (!stringr::str_detect(file, '.xls')) {stop('Please provide an Excel file')}
  if (is.null(sheetname)) {sheetname <- getsheets(file)[1]}
  df <- rdexcelnu(file, sheet = sheetname) |> data.table::as.data.table()
  if(skiprows>0){skiprows=as.integer(skiprows);df=df[-(1:skiprows),]}
  colnames(df) <- unlist(head(df, 1))
  df <- df[-1, ]
  df=suppressWarnings({utils::type.convert(df)})
  return(df)
}
